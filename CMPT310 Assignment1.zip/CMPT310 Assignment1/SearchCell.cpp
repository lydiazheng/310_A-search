//
//  SearchCell.cpp
//  cmpt-310 A1
//
//  Created by Lynn on 2016-10-08.
//  Copyright © 2016 Lydia. All rights reserved.
//

#include "SearchCell.h"
