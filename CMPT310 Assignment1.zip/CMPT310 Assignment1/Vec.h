//
//  Vec.h
//  cmpt-310 A1
//
//  Created by Lynn on 2016-10-01.
//  Copyright © 2016 Lydia. All rights reserved.
//

#pragma once

class Vec {
public:
    int x;
    int y;
    int z;
    Vec(void);
    Vec(int xcoord, int ycoord, int zcoord);
    
};
